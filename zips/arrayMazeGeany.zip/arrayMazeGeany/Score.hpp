#ifndef Score_hpp
#define Score_hpp

#include <stdio.h>
#pragma once
#include <iostream>
#include <string>

using namespace std;

class score
{
	private:
		string name;
		int turns;
		int errors;
		int total;
	public:
		score();
		score(string name, int turns, int errors, int total);
		string getName();
		int getTurns();
		int getErrors();
		int getTotal();
		void print();
};

#endif
