#include "Score.hpp"
#include <iostream>
#include <string>

using namespace std;

score::score()
{
	name = "Empty";
	turns = 699;
	errors = 100;
	total = 999;
}

score::score(string name, int turns, int errors, int total)
{
    this->name = name;
    this->turns = turns;
    this->errors = errors;
    this->total = total;
}

string score::getName()
{
	return name;
}

int score::getTurns()
{
	return turns;
}

int score::getErrors()
{
	return errors;
}

int score::getTotal()
{
	return total;
}

void score::print()
{
    cout << "Here is " << name << "'s score (the lower the better):" << endl << "Turns taken: " << turns << endl << "Errors made (worth 3 points): " << errors << endl << "Total score: " << total << endl;
}
