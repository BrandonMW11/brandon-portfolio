//
//  main.cpp
//  ArrayMaze
//
//  Created by Brandon Waltersdorf on 3/3/24.
//  Last modified by Zachary Roehr on 3/10/24
//

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include "Score.cpp"

using namespace std;

void printMaze(char** maze, int mazeHeight, int mazeWidth)
{
    cout << endl;
    for(int i = 0; i < mazeHeight; i++)
    {
        for(int j = 0; j < mazeWidth; j++)
        {
            cout << maze[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

int countAndPrint(string path){
    ifstream fin;
    int count = 0;
    
    fin.open(path);
    if(fin.is_open()){
        while(true){
            string line;
            getline(fin, line);
            if(fin.fail()){
                break;
            }
            for(int i = 0; i < static_cast<int>(line.length()); i++){
                cout << line[i] << " ";
            }
            cout << endl;
            count++;
        }
    }else{
        cout << "File could not be opened.\n";
    }
    fin.close();
    return count;
}

// wirtes new scores to the scoreboard
void writeScoreboard(string playerName, int turnsTaken, int errorsMade, int totalScore)
{
	string path = "Scoreboard.csv";
	ofstream output;
	
	output.open(path, ios::app);
	if(output.is_open())
	{
		output << playerName << "," << turnsTaken << "," << errorsMade << "," << totalScore << endl;
		cout << "Your score has been successfully added to the scoreboard." << endl;
	}
	else
	{
		cout << "Unable to add you score to the scoreboard." << endl;
	}
	
	output.close();
}

// Counts how many lines are in the scoreboard
int countLines()
{
	int lines = 0;
	string path = "Scoreboard.csv";
	ifstream input;
	
	input.open(path);
    if(input.is_open())
    {
        string data;
        while(getline(input, data))
        {
            lines++;
        }
    }
    else
    {
        cout << "Failed to access scoreboard." << endl;
    }
    
    input.close();
    return lines;
}

// Reads the scoreboard and puts it in an array
score * readScoreboard(int lines)
{
	string path = "Scoreboard.csv";
	score * scoreboard = new score[lines];
	ifstream input;
	
	input.open(path);
	if(input.is_open())
    {
        string line;
        getline(input, line);
        for(int i = 0; i < lines - 1; i++)
        {
            string name;
            getline(input, name, ',');
            
            string turnsStr;
            getline(input, turnsStr, ',');
            int turns = stoi(turnsStr);
            
            string errorsStr;
            getline(input, errorsStr, ',');
            int errors = stoi(errorsStr);
            
            string totalStr;
            getline(input, totalStr);
            int total = stoi(totalStr);
            
            scoreboard[i] = score(name, turns, errors, total);
        }
    }
    else
    {
        cout << "Failed to access scoreboard." << endl;
        input.close();
        exit(0);
    }
	
	input.close();
	return scoreboard;
}

// Sorts the scoreboard array
void sortScoreboard(score scoreboard[], int lines)
{
	int total1, total2;
    string name1, name2;
    
    for(int a = 0; a < lines - 1; a++)
    {
        total1 = scoreboard[a].getTotal();
        name1 = scoreboard[a].getName();
        for(int b = a + 1; b < lines - 1; b++)
        {
            total2 = scoreboard[b].getTotal();
            name2 = scoreboard[b].getName();
            if(total1 > total2)
            {
                swap(scoreboard[a], scoreboard[b]);
            }
            else if(total1 == total2)
            {
                if(name1 > name2)
                {
                    swap(scoreboard[a], scoreboard[b]);
                }
            }
            total1 = scoreboard[a].getTotal();
            total2 = scoreboard[b].getTotal();
            name1 = scoreboard[a].getName();
            name2 = scoreboard[b].getName();
        }
    }
}

// Changes the csv file to be the 
void writeSortedScoreboard(score scoreboard[], int lines)
{
	string path = "Scoreboard.csv";
	ofstream output;
	
	output.open(path);
	if(output.is_open())
	{
		output << "Name" << "," << "Turns" << "," << "Errors" << "," << "Total" << endl;
		for(int i = 0; i < lines - 1; i++)
		{
			output << scoreboard[i].getName() << "," << scoreboard[i].getTurns() << "," << scoreboard[i].getErrors() << "," << scoreboard[i].getTotal() << endl;
		}
	}
	else
	{
		cout << "Failed to access scoreboard." << endl;
	}
	
	output.close();
}

int main()
{
    bool continuePlaying = true;
    ifstream fin;
    const int pathsLen = 2;
    int mazeHeight, mazeWidth;
    string playerName;
    string paths[pathsLen] = {"maze1.maze", "maze2.maze"};
    char** maze;
    do{
        bool playerWon = false, valid = false, mazePicked = false;
        int lines, mazeChoice, scoreboardChoice, moveLength = 0, directionChoice = 0, plusPosX = 0, turnsTaken = 0, errorsMade = 0, totalScore = 0, plusPosY = 1;
        
        // Retrieves the scoreboard data
        lines = countLines();
        score * scoreboard = readScoreboard(lines);
        sortScoreboard(scoreboard, lines);
        writeSortedScoreboard(scoreboard, lines);
        
        // Player enters their name
        do{
			cout << "Enter your name: ";
			getline(cin, playerName);
			if(playerName.length() == 0)
			{
				cout << "Please enter a name." << endl << endl;
			}
			else
			{
				valid = true;
			}
		}while(!valid);
		valid = false;
        
        // Preview mazes or check the scoreboard
        do{
            do{
				cout << "Pick a maze to preview...\n";
				for(int i = 0; i < pathsLen; i++){
					cout << i+1 << ") " << paths[i] << "\n";
				}
				cout << "0) View the scoreboard" << endl;
                cout << "> ";
                cin >> mazeChoice;
                cin.ignore();
                if(mazeChoice == 0)
                {
					do{
						cout << "1) View the top 5 scores" << endl << "2) View all scores" << endl << "> ";
						cin >> scoreboardChoice;
						cout << endl;
						switch(scoreboardChoice)
						{
							case 1:
								for(int i = 0; i < 5; i++)
								{
									cout << scoreboard[i].getName() << ": " << scoreboard[i].getTotal() << endl;
								}
								break;
							case 2:
								for(int i = 0; i < lines - 1; i++)
								{
									cout << scoreboard[i].getName() << ": " << scoreboard[i].getTotal() << endl;
								}
								break;
							default:
								cout << "Invalid input, try again." << endl << endl;
						}
					}while(scoreboardChoice  != 1 && scoreboardChoice  != 2);
					cout << endl;
				}
            }while(mazeChoice < 1 || mazeChoice > pathsLen);
            mazeHeight = countAndPrint(paths[mazeChoice - 1]);
            cout << endl << "Is this the maze you want to play? (y/n)\n> ";
            do{
                string mazeConfirm;
                getline(cin, mazeConfirm);
                if(mazeConfirm == "y" || mazeConfirm == "Y"){
                    valid = true;
                    mazePicked = true;
                }else if(mazeConfirm == "n" || mazeConfirm == "N"){
                    valid = true;
                }else{
                    cout << "Invalid input, try again.\n>";
                }
            }while(!valid);
            valid = false;
        }while(!mazePicked);
        
        // Load maze into array
        fin.open(paths[mazeChoice - 1]);
        if(fin.is_open()){
            string line;
            getline(fin, line);
            mazeWidth = line.length();
            cout << mazeWidth << endl;
            maze = new char*[mazeHeight];
            for(int i = 0; i < mazeHeight; i++){
                maze[i] = new char[mazeWidth];
            }
            for(int i = 0; i < mazeWidth; i++){
                maze[0][i] = line[i];
            }
            for(int i = 1; i < mazeHeight; i++){
                getline(fin, line);
                if(fin.fail()){
                    break;
                }
                for(int j = 0; j < mazeWidth; j++){
                    maze[i][j] = line[j];
                    if(line[j] == '+'){
                        plusPosX = j;
                        plusPosY = i;
                    }
                }
            }
        }else{
            cout << "Could not load maze.\n";
        }
        fin.close();
        
        // Main gameloop
        while(playerWon == false)
        {
			turnsTaken++;
            printMaze(maze, mazeHeight, mazeWidth);
            
            while(valid == false)
            {
                cout << "Which direction would you like to go in?" << endl << "1) Left" << endl << "2) Up" << endl << "3) Down" << endl << "4) Right" << endl << "Your choice: ";
                cin >> directionChoice;
                cin.ignore();
                if(directionChoice < 1 || directionChoice > 4)
                {
                    cout << "Invalid choice!" << endl << endl;
                }
                else
                {
                    valid = true;
                }
            }
            valid = false;
            
            while(valid == false)
            {
                cout << endl << "How many spaces will you move in that direction?" << endl << "Your choice: ";
                cin >> moveLength;
                cin.ignore();
                if(moveLength < 1)
                {
                    cout << "Invalid choice!" << endl << endl;
                }
                else
                {
                    valid = true;
                }
            }
            valid = false;
            
            switch (directionChoice)
            {
                case 1:
                    for(int i = 0; i < moveLength; i++, plusPosX--)
                    {
                        maze[plusPosY][plusPosX] = ' ';
                        if(maze[plusPosY][plusPosX - 1] == '*')
                        {
							errorsMade++;
                            maze[plusPosY][plusPosX - 1] = '+';
                            printMaze(maze, mazeHeight, mazeWidth);
                            cout << "You hit a wall!" << endl << endl;
                            maze[plusPosY][plusPosX - 1] = '*';
                            plusPosX = 0;
                            plusPosY = 1;
                            maze[plusPosY][plusPosX] = '+';
                            break;
                        }
                        else if(maze[plusPosY][plusPosX - 1] == 'E')
                        {
                            playerWon = true;
                            break;
                        }
                        maze[plusPosY][plusPosX - 1] = '+';
                    }
                    break;
                case 2:
                    for(int i = 0; i < moveLength; i++, plusPosY--)
                    {
                        maze[plusPosY][plusPosX] = ' ';
                        if(maze[plusPosY - 1][plusPosX] == '*')
                        {
							errorsMade++;
                            maze[plusPosY - 1][plusPosX] = '+';
                            printMaze(maze, mazeHeight, mazeWidth);
                            cout << "You hit a wall!" << endl << endl;
                            maze[plusPosY - 1][plusPosX] = '*';
                            plusPosX = 0;
                            plusPosY = 1;
                            maze[plusPosY][plusPosX] = '+';
                            break;
                        }
                        else if(maze[plusPosY - 1][plusPosX] == 'E')
                        {
                            playerWon = true;
                            break;
                        }
                        maze[plusPosY - 1][plusPosX] = '+';
                    }
                    break;
                case 3:
                    for(int i = 0; i < moveLength; i++, plusPosY++)
                    {
                        maze[plusPosY][plusPosX] = ' ';
                        if(maze[plusPosY + 1][plusPosX] == '*')
                        {
							errorsMade++;
                            maze[plusPosY + 1][plusPosX] = '+';
                            printMaze(maze, mazeHeight, mazeWidth);
                            cout << "You hit a wall!" << endl << endl;
                            maze[plusPosY + 1][plusPosX] = '*';
                            plusPosX = 0;
                            plusPosY = 1;
                            maze[plusPosY][plusPosX] = '+';
                            break;
                        }
                        else if(maze[plusPosY + 1][plusPosX] == 'E')
                        {
                            playerWon = true;
                            break;
                        }
                        maze[plusPosY + 1][plusPosX] = '+';
                    }
                    break;
                case 4:
                    for(int i = 0; i < moveLength; i++, plusPosX++)
                    {
                        maze[plusPosY][plusPosX] = ' ';
                        if(maze[plusPosY][plusPosX + 1] == '*')
                        {
							errorsMade++;
                            maze[plusPosY][plusPosX + 1] = '+';
                            printMaze(maze, mazeHeight, mazeWidth);
                            cout << "You hit a wall!" << endl << endl;
                            maze[plusPosY][plusPosX + 1] = '*';
                            plusPosX = 0;
                            plusPosY = 1;
                            maze[plusPosY][plusPosX] = '+';
                            break;
                        }
                        else if(maze[plusPosY][plusPosX + 1] == 'E')
                        {
                            playerWon = true;
                            break;
                        }
                        maze[plusPosY][plusPosX + 1] = '+';
                    }
                    break;
                default:
                    break;
            }
        }
        
        maze[plusPosY][plusPosX + 1] = '+';
        cout << endl << "You won" << endl;
        printMaze(maze, mazeHeight, mazeWidth);
        
        // Prints the player's score and updates the scoreboard
        totalScore = turnsTaken + (errorsMade * 3);
        score playerScore(playerName, turnsTaken, errorsMade, totalScore);
        playerScore.print();
        writeScoreboard(playerName, turnsTaken, errorsMade, totalScore);
        lines = countLines();
        scoreboard = readScoreboard(lines);
        sortScoreboard(scoreboard, lines);
        writeSortedScoreboard(scoreboard, lines);
        
        cout << "\nPlay again? (y/n)\n> ";
        do{
            string playAgain;
            getline(cin, playAgain);
            if(playAgain == "y" || playAgain == "Y"){
                valid = true;
            }else if(playAgain == "n" || playAgain == "N"){
                valid = true;
                continuePlaying = false;
                cout << "Thanks for playing!\n";
            }else{
                cout << "Invalid input, try again.\n> ";
            }
        }while(!valid);
        valid = false;
        
        // Free old maze memory
        for(int i = 0; i < mazeHeight; i++){
            delete[] maze[i];
        }
        delete[] maze;
    }while(continuePlaying);
    
    return 0;
}

