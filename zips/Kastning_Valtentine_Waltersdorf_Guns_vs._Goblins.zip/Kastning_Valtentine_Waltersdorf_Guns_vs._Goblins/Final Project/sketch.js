﻿var playerNeutral;
var playerUp;
var playerLeft;
var playerRight;
var playerDirection = 0;
var aim = 21;
var playerPosX = 350;
var playerPosY = 350;
var playerBullet = [];
var pBullet;
var playerFire;
var playerHit;
var playerDie;
var playerHealth = 8;
var healthCubeX = [20, 70, 120, 170, 220, 270, 320, 370];
var enemyMelee;
var enemyPosX = 800;
var enemyPosY = 400;
var enemyUp;
var enemyDown;
var enemyLeft;
var enmeyRight;
var enemyDirection = 0;
var enemyBullet = [];
var eBullet;
var enemyFire;
var rateOfFire = 0;
var enemyMeleeHealth = 10;
var enemyShooterHealth = 5;
var enemyDie;
var iFrames = 41;
var meleeLimit = 0;
var rangedLimit = 0;
var points = 0;
var enemies = [];
var rangedEnemies = 0;
var meleeEnemies = 0;
var refresh = 60;

function preload() {
    playerNeutral = loadImage("Main_Neutral.png");
    playerUp = loadImage("Main_Up.png");
    playerLeft = loadImage("Main_Left.png");
    playerRight = loadImage("Main_Right.png");
    enemyMelee = loadImage("Melee-Enemy.png");
    enemyUp = loadImage("Ranged_Enemy_Back.png");
    enemyDown = loadImage("Ranged_Enemy_Forward.png");
    enemyLeft = loadImage("Ranged_Enemy_Left.png");
    enemyRight = loadImage("Ranged_Enemy_Right.png");
    pBullet = loadImage("Main_Bullet.png");
    eBullet = loadImage("Enemy_Bullet.png");
    playerFire = loadSound("playerShoots.mp3");
    enemyFire = loadSound("enemyShoots.mp3");
    playerHit = loadSound("playerHurt.mp3");
    playerDie = loadSound("playerDeath.mp3");
    enemyDie = loadSound("EnemyHurt.mp3");
}
function setup() {
    createCanvas(800, 800);
    frameRate(60);
    textAlign(CENTER);
}

function draw() {
    background(210);
    arrows();
    if (playerHealth > 0) {
        spawnEnemies();
        playersBullets();
        playerFacing();
        activeEnemy();
        activeEnemy2();
        enemiesBullets();
        if (rateOfFire <= 60) {
            rateOfFire += 1;
        }
        if (aim <= 20) {
            aim += 1;
        }
    } else {
        push();
        textSize(50);
        fill(255, 0, 0);
        text('YOU DIED', 400, 400);
        pop();
    }
    damagePlayer();
    if (iFrames <= 40) {
        iFrames += 1;
    }
    rect(0, 0, width, 75);
    push();
    textSize(50);
    fill(255, 0, 0);
    text('SCORE: ' + points, 600, 50);
    pop();
    for (i = 0; i < playerHealth; i++) {
        push();
        strokeWeight(4);
        fill(255, 0, 0);
        rect(healthCubeX[i], 15, 45, 45);
        pop();
    }
    meleeLimit = points / 10 + 1;
    rangedLimit = points / 20 + 1;
}

function arrows() {
    if (keyIsDown(UP_ARROW)) {
        if (aim > 20) {
            playerDirection = 1;
        }
        if (playerPosY >= 75) {
            playerPosY -= 5;
        }
    }
    if (keyIsDown(DOWN_ARROW)) {
        if (aim > 20) {
            playerDirection = 0;
        }
        if (playerPosY <= (height - 75)) {
            playerPosY += 5;
        }
    }
    if (keyIsDown(LEFT_ARROW)) {
        if (aim > 20) {
            playerDirection = 2;
        }
        if (playerPosX >= 0) {
            playerPosX -= 5;
        }
    }
    if (keyIsDown(RIGHT_ARROW)) {
        if (aim > 20) {
            playerDirection = 4;
        }
        if (playerPosX <= (width - 75)) {
            playerPosX += 5;
        }
    }
}

function playersBullets() {
    for (var i = 0; i < playerBullet.length; i++) {
        if (playerBullet[i][0] == 0) {
            if (playerBullet[i][2] > -30) {
                playerBullet[i][2] -= 10
            }
        }
        else if (playerBullet[i][0] == 1) {
            if (playerBullet[i][2] < 830) {
                playerBullet[i][2] += 10
            }
        }
        else if (playerBullet[i][0] == 2) {
            if (playerBullet[i][1] > -30) {
                playerBullet[i][1] -= 10
            }
        }
        else if (playerBullet[i][0] == 3) {
            if (playerBullet[i][1] < 830) {
                playerBullet[i][1] += 10
            }
        }
        for(var j = 0; j < enemies.length; j++){
            if ((playerBullet[i][1] > enemies[j][1] - 25 && playerBullet[i][1] < enemies[j][1] + 125) && (playerBullet[i][2] > enemies[j][2] - 25 && playerBullet[i][2] < enemies[j][2] + 125)) {
                enemies[j][3] -= 1
                playerBullet[i][1] = 1000000000
                if (enemies[j][3] == 0) {
                    if (enemies[j][0] == 0) {
                        meleeEnemies--
                        points++
                    }
                    else {
                        rangedEnemies--
                        points++
                    }
                    enemies.splice(j, 1)
                    enemyDie.play();
                }
            }
        }
        image(pBullet, (playerBullet[i][1] - 37.5), (playerBullet[i][2] - 37.5), 100, 100);
    }
}

function keyTyped() {
    if (key == 'w') {
        aim = 0;
        if (aim <= 20) {
            playerDirection = 1;
        }
        playerFire.play();
        playerBullet[playerBullet.length] = [];
        playerBullet[playerBullet.length - 1][0] = 0;
        playerBullet[playerBullet.length - 1][1] = playerPosX + 25;
        playerBullet[playerBullet.length - 1][2] = playerPosY + 25;
    } else if (key == 's') {
        aim = 0;
        if (aim <= 20) {
            playerDirection = 0;
        }
        playerFire.play();
        playerBullet[playerBullet.length] = [];
        playerBullet[playerBullet.length - 1][0] = 1;
        playerBullet[playerBullet.length - 1][1] = playerPosX + 25;
        playerBullet[playerBullet.length - 1][2] = playerPosY + 25;
    } else if (key == 'a') {
        aim = 0;
        if (aim <= 20) {
            playerDirection = 2;
        }
        playerFire.play();
        playerBullet[playerBullet.length] = [];
        playerBullet[playerBullet.length - 1][0] = 2;
        playerBullet[playerBullet.length - 1][1] = playerPosX + 25;
        playerBullet[playerBullet.length - 1][2] = playerPosY + 25;
    } else if (key == 'd') {
        aim = 0;
        if (aim <= 20) {
            playerDirection = 3;
        }
        playerFire.play();
        playerBullet[playerBullet.length] = [];
        playerBullet[playerBullet.length - 1][0] = 3;
        playerBullet[playerBullet.length - 1][1] = playerPosX + 25;
        playerBullet[playerBullet.length - 1][2] = playerPosY + 25;
    }
}

function playerFacing() {
    if (playerDirection == 0) {
        image(playerNeutral, playerPosX, playerPosY, 75, 75);
    } else if (playerDirection == 1) {
        image(playerUp, playerPosX, playerPosY, 75, 75);
    } else if (playerDirection == 2) {
        image(playerLeft, playerPosX, playerPosY, 75, 75);
    } else {
        image(playerRight, playerPosX, playerPosY, 75, 75);
    }
}

function activeEnemy() {
    for(var i = 0; i < enemies.length; i++){
        if(enemies[i][0] == 0){
            if (enemies[i][1] > (playerPosX - 25)) {
                enemies[i][1] -= 2;
            } else if (enemies[i][1] < (playerPosX - 25)) {
                enemies[i][1] += 2;
            }
            if (enemies[i][2] > (playerPosY - 25)) {
                enemies[i][2] -= 2;
            } else if (enemies[i][2] < (playerPosY - 25)) {
                enemies[i][2] += 2;
            }
            image(enemyMelee, enemies[i][1], enemies[i][2], 125, 125);
        }
    }
}

function enemiesBullets() {
    if (rateOfFire > 60) {
        enemyFire.play();
        for(var i = 0; i < enemies.length; i ++){
            if(enemies[i][0] == 1){
                if(abs(enemies[i][2] - playerPosY) > abs(enemies[i][1] - playerPosX)){
                    if(enemies[i][2] - playerPosY > 0){
                        enemyBullet[enemyBullet.length] = []
                        enemyBullet[enemyBullet.length-1][0] = 0
                        enemyBullet[enemyBullet.length - 1][1] = enemies[i][1] + 50
                        enemyBullet[enemyBullet.length - 1][2] = enemies[i][2] + 50
                        enemies[i][4] = 0;
                    }
                    else{
                        enemyBullet[enemyBullet.length] = []
                        enemyBullet[enemyBullet.length-1][0] = 1
                        enemyBullet[enemyBullet.length - 1][1] = enemies[i][1] + 50
                        enemyBullet[enemyBullet.length - 1][2] = enemies[i][2] + 50
                        enemies[i][4] = 1;
                    }
                }
                else{
                    if(enemies[i][1] - playerPosX > 0){
                        enemyBullet[enemyBullet.length] = []
                        enemyBullet[enemyBullet.length-1][0] = 2
                        enemyBullet[enemyBullet.length - 1][1] = enemies[i][1] + 50
                        enemyBullet[enemyBullet.length - 1][2] = enemies[i][2] + 50
                        enemies[i][4] = 2;
                    }
                    else{
                        enemyBullet[enemyBullet.length] = []
                        enemyBullet[enemyBullet.length-1][0] = 3
                        enemyBullet[enemyBullet.length - 1][1] = enemies[i][1] + 50
                        enemyBullet[enemyBullet.length - 1][2] = enemies[i][2] + 50
                        enemies[i][4] = 3;
                    }
                }
            }
        }
        rateOfFire = 0;
    }
    for (var i = 0; i < enemyBullet.length; i++) {
        if(enemyBullet[i][0] == 0){
            if(enemyBullet[i][2] > -30){
               enemyBullet[i][2] -= 10
            }
        }
        if(enemyBullet[i][0] == 1){
            if(enemyBullet[i][2] < 830){
               enemyBullet[i][2] += 10
            }
        }
        if(enemyBullet[i][0] == 2){
            if(enemyBullet[i][1] > -30){
               enemyBullet[i][1] -= 10
            }
        }
        if(enemyBullet[i][0] == 3){
            if(enemyBullet[i][1] < 830){
               enemyBullet[i][1] += 10
            }
        }
        if ((((enemyBullet[i][1] >= playerPosX) && ((enemyBullet[i][1] + 25) <= (playerPosX + 75))) && ((enemyBullet[i][2] >= playerPosY) && ((enemyBullet[i][2] + 25) <= (playerPosY + 75)))) && (iFrames > 40)) {
            playerHealth -= 1;
            if (playerHealth == 0) {
                playerDie.play();
            } else if (playerHealth > 0){
                playerHit.play();
            }
            iFrames = 0;
        }
        image(eBullet, (enemyBullet[i][1] - 37.5), (enemyBullet[i][2] - 37.5), 100, 100);
    }
}

function spawnEnemies() {
    if(refresh > 60){
        if (rangedEnemies < rangedLimit) {
            refresh = 0
            enemies[enemies.length] = []
            enemies[enemies.length - 1][0] = 1
            var r = random(0, 4)
            if (r < 1) {
                enemies[enemies.length - 1][1] = -100
                enemies[enemies.length - 1][2] = -100
            }
            else if (r < 2) {
                enemies[enemies.length - 1][1] = -100
                enemies[enemies.length - 1][2] = 900
            }
            else if (r < 3) {
                enemies[enemies.length - 1][1] = 900
                enemies[enemies.length - 1][2] = 900
            }
            else {
                enemies[enemies.length - 1][1] = 900
                enemies[enemies.length - 1][2] = -100
            }
            enemies[enemies.length - 1][3] = 5;
            enemies[enemies.length - 1][4] = 0;
            rangedEnemies ++;
        }
        else if(meleeEnemies < meleeLimit){
            refresh = 0
            enemies[enemies.length] = []
            enemies[enemies.length - 1][0] = 0
            var r = random(0,4)
            if(r < 1){
                enemies[enemies.length - 1][1] = -100
                enemies[enemies.length - 1][2] = -100
            }
            else if(r < 2){
                enemies[enemies.length - 1][1] = -100
                enemies[enemies.length - 1][2] = 900
            }
            else if(r < 3){
                enemies[enemies.length - 1][1] = 900
                enemies[enemies.length - 1][2] = 900
            }
            else{
                enemies[enemies.length - 1][1] = 900
                enemies[enemies.length - 1][2] = -100
            }
            enemies[enemies.length - 1][3] = 10;
            meleeEnemies ++
        }
    }
    refresh += 1 + points/25
}

function activeEnemy2() {
    for(var i = 0; i < enemies.length; i++){
        if(enemies[i][0] == 1){
            if(abs(enemies[i][1] - playerPosX) > abs(enemies[i][2] - playerPosY)){
                if (enemies[i][1] > (playerPosX + 175)) {
                    enemies[i][1] -= 3;
                } else if (enemies[i][1] < (playerPosX - 275)) {
                    enemies[i][1] += 3;
                } else if ((enemies[i][1] >= (playerPosX)) && (enemies[i][1] <= (playerPosX + 175))) {
                    enemies[i][1] += 2;
                } else if ((enemies[i][1] >= (playerPosX - 275)) && (enemies[i][1] <= (playerPosX))) {
                    enemies[i][1] -= 2;
                }
                if (enemies[i][2] > (playerPosY - 25)) {
                    enemies[i][2] -= 3;
                } else if (enemies[i][2] < (playerPosY - 25)) {
                    enemies[i][2] += 3;
                }
            }
            else{
                if (enemies[i][2] > (playerPosY + 175)) {
                    enemies[i][2] -= 3;
                } else if (enemies[i][2] < (playerPosY - 275)) {
                    enemies[i][2] += 3;
                } else if ((enemies[i][2] >= (playerPosY)) && (enemies[i][2] <= (playerPosY + 175))) {
                    enemies[i][2] += 2;
                } else if ((enemies[i][2] >= (playerPosY - 275)) && (enemies[i][2] <= (playerPosY))) {
                    enemies[i][2] -= 2;
                }
                if (enemies[i][1] > (playerPosX - 25)) {
                    enemies[i][1] -= 3;
                } else if (enemies[i][1] < (playerPosX - 25)) {
                    enemies[i][1] += 3;
                }
            }
            if (enemies[i][4] == 0) {
                image(enemyUp, enemies[i][1], enemies[i][2], 125, 125);
            } else if (enemies[i][4] == 1) {
                image(enemyDown, enemies[i][1], enemies[i][2], 125, 125);
            } else if (enemies[i][4] == 2) {
                image(enemyLeft, enemies[i][1], enemies[i][2], 125, 125);
            } else {
                image(enemyRight, enemies[i][1], enemies[i][2], 125, 125);
            }
        }
    }
}

function damagePlayer() {
    for(var i = 0; i < enemies.length; i++){
        if(enemies[i][0] == 0){
            if ((((playerPosX >= enemies[i][1]) && ((playerPosX + 75) <= (enemies[i][1] + 125))) && ((playerPosY >= enemies[i][2]) && ((playerPosY + 75) <= (enemies[i][2] + 125)))) && (iFrames > 40)) {
                playerHealth -= 1;
                if (playerHealth == 0) {
                    playerDie.play();
                } else if (playerHealth > 0) {
                    playerHit.play();
                }
                iFrames = 0;
            }
        }
    }
    for (var i = 0; i < enemies.length; i ++){
        if(enemies[i][0] == 1){
            if ((((playerPosX >= enemies[i][1]) && ((playerPosX + 75) <= (enemies[i][1] + 125))) && ((playerPosY >= enemies[i][2]) && ((playerPosY + 75) <= (enemies[i][2] + 125)))) && (iFrames > 40)) {
                playerHealth -= 1;
                if (playerHealth == 0) {
                    playerDie.play();
                } else if (playerHealth > 0) {
                    playerHit.play();
                }
                iFrames = 0;
            }
        }
    }
}