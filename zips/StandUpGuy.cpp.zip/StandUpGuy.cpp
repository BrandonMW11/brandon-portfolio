#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>

using namespace std;

unsigned int choice;
unsigned int stars;
int audienceMood = 2;
unsigned int roundCounter = 1;
unsigned int dragging = 0;
bool prompt9good = true;
bool prompt10good = true;
bool prompt11good = true;
bool prompt12good = true;
bool prompt13good = true;
bool prompt14good = true;
bool prompt15good = true;
bool prompt16good = true;
bool prompt17good = true;
bool prompt18good = true;
bool prompt19good = true;
bool prompt20good = true;
bool prompt21good = true;
bool prompt22good = true;
bool prompt23good = true;
bool prompt24good = true;
bool prompt25good = true;
bool prompt26good = true;
bool prompt27good = false;
bool prompt27amazing = false;
bool prompt27awful = false;

void firstChoice()
{
	switch(choice)
	{
		case 1:
			prompt9good = true;
			prompt10good = false;
			prompt11good = false;
			prompt12good = true;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = false;
			prompt20good = false;
			prompt21good = false;
			prompt22good = true;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			break;
		case 2:
			prompt9good = true;
			prompt10good = false;
			prompt11good = false;
			prompt12good = true;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = true;
			prompt20good = true;
			prompt21good = true;
			prompt22good = true;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			break;
		case 3:
			prompt9good = false;
			prompt10good = false;
			prompt11good = false;
			prompt12good = true;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = false;
			prompt20good = false;
			prompt21good = false;
			prompt22good = true;
			prompt23good = false;
			prompt24good = false;
			prompt25good = false;
			prompt26good = false;
			break;
		case 4:
			prompt9good = false;
			prompt10good = true;
			prompt11good = true;
			prompt12good = true;
			prompt13good = false;
			prompt14good = false;
			prompt15good = false;
			prompt16good = true;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = false;
			prompt22good = true;
			prompt23good = true;
			prompt24good = false;
			prompt25good = true;
			prompt26good = false;
			break;
		case 5:
			prompt9good = true;
			prompt10good = false;
			prompt11good = false;
			prompt12good = true;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = false;
			prompt20good = true;
			prompt21good = false;
			prompt22good = true;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			break;
		case 6:
			prompt9good = true;
			prompt10good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = false;
			prompt20good = false;
			prompt21good = false;
			prompt22good = true;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			break;
		case 7:
			prompt9good = false;
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = true;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = true;
			prompt22good = true;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			break;
		case 8:
			prompt9good = true;
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = false;
			prompt16good = true;
			prompt17good = true;
			prompt18good = true;
			prompt19good = false;
			prompt20good = true;
			prompt21good = true;
			prompt22good = true;
			prompt23good = true;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			break;
	}
}

void storyChoice()
{
	cout << endl << "----------" << endl << endl;
	switch(choice)
	{
		case 9:
			if(prompt9good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = false;
			prompt16good = true;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = true;
			prompt22good = false;
			prompt23good = true;
			prompt24good = false;
			prompt25good = true;
			prompt26good = false;
			prompt27good = false;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 10:
			if(prompt10good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = false;
			prompt14good = true;
			prompt15good = false;
			prompt16good = true;
			prompt17good = true;
			prompt18good = false;
			prompt19good = true;
			prompt20good = false;
			prompt21good = true;
			prompt22good = false;
			prompt23good = true;
			prompt24good = false;
			prompt25good = true;
			prompt26good = false;
			prompt27good = false;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 11:
			if(prompt11good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = false;
			prompt16good = true;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = false;
			prompt21good = true;
			prompt22good = false;
			prompt23good = false;
			prompt24good = false;
			prompt25good = true;
			prompt26good = false;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 12:
			if(prompt12good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = true;
			prompt10good = true;
			prompt11good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = true;
			prompt17good = false;
			prompt18good = true;
			prompt19good = false;
			prompt20good = true;
			prompt21good = false;
			prompt22good = true;
			prompt23good = true;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			prompt27good = false;
			prompt27amazing = false;
			prompt27awful = true;
			break;
		case 13:
			if(prompt13good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = true;
			prompt12good = false;
			prompt14good = false;
			prompt15good = true;
			prompt16good = true;
			prompt17good = false;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = false;
			prompt22good = true;
			prompt23good = false;
			prompt24good = false;
			prompt25good = false;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 14:
			if(prompt14good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = true;
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = false;
			prompt15good = false;
			prompt16good = false;
			prompt17good = true;
			prompt18good = false;
			prompt19good = true;
			prompt20good = true;
			prompt21good = false;
			prompt22good = false;
			prompt23good = false;
			prompt24good = false;
			prompt25good = false;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 15:
			if(prompt15good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = true;
			prompt14good = false;
			prompt16good = true;
			prompt17good = false;
			prompt18good = false;
			prompt19good = true;
			prompt20good = false;
			prompt21good = false;
			prompt22good = true;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 16:
			if(prompt16good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = false;
			prompt22good = false;
			prompt23good = false;
			prompt24good = false;
			prompt25good = true;
			prompt26good = true;
			prompt27good = false;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 17:
			if(prompt17good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = true;
			prompt14good = false;
			prompt15good = false;
			prompt16good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = true;
			prompt22good = true;
			prompt23good = true;
			prompt24good = false;
			prompt25good = true;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 18:
			if(prompt18good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = true;
			prompt14good = false;
			prompt15good = false;
			prompt16good = true;
			prompt17good = true;
			prompt19good = true;
			prompt20good = true;
			prompt21good = true;
			prompt22good = false;
			prompt23good = true;
			prompt24good = false;
			prompt25good = true;
			prompt26good = false;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 19:
			if(prompt19good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = true;
			prompt12good = false;
			prompt13good = true;
			prompt14good = true;
			prompt15good = true;
			prompt16good = false;
			prompt17good = true;
			prompt18good = true;
			prompt20good = true;
			prompt21good = false;
			prompt22good = false;
			prompt23good = false;
			prompt24good = false;
			prompt25good = true;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = true;
			prompt27awful = false;
			break;
		case 20:
			if(prompt20good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = true;
			prompt14good = false;
			prompt15good = false;
			prompt16good = false;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt21good = true;
			prompt22good = false;
			prompt23good = false;
			prompt24good = false;
			prompt25good = true;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 21:
			if(prompt21good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = true;
			prompt11good = true;
			prompt12good = false;
			prompt13good = false;
			prompt14good = true;
			prompt15good = false;
			prompt16good = false;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = true;
			prompt22good = false;
			prompt23good = false;
			prompt24good = false;
			prompt25good = true;
			prompt26good = false;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 22:
			if(prompt22good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = true;
			prompt14good = false;
			prompt15good = true;
			prompt16good = false;
			prompt17good = false;
			prompt18good = true;
			prompt19good = true;
			prompt20good = false;
			prompt21good = false;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt26good = false;
			prompt27good = false;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 23:
			if(prompt23good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = true;
			prompt11good = false;
			prompt12good = false;
			prompt13good = false;
			prompt14good = false;
			prompt15good = false;
			prompt16good = false;
			prompt17good = true;
			prompt18good = true;
			prompt19good = true;
			prompt20good = false;
			prompt21good = false;
			prompt22good = false;
			prompt24good = true;
			prompt25good = true;
			prompt26good = true;
			prompt27good = false;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 24:
			if(prompt24good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = true;
			prompt12good = false;
			prompt13good = false;
			prompt14good = false;
			prompt15good = false;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = true;
			prompt20good = false;
			prompt21good = false;
			prompt22good = true;
			prompt23good = true;
			prompt25good = true;
			prompt26good = true;
			prompt27good = true;
			prompt27amazing = true;
			prompt27awful = false;
			break;
		case 25:
			if(prompt25good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = true;
			prompt11good = false;
			prompt12good = true;
			prompt13good = false;
			prompt14good = false;
			prompt15good = false;
			prompt16good = false;
			prompt17good = true;
			prompt18good = true;
			prompt19good = false;
			prompt20good = true;
			prompt21good = true;
			prompt22good = true;
			prompt23good = true;
			prompt24good = true;
			prompt26good = false;
			prompt27good = true;
			prompt27amazing = false;
			prompt27awful = false;
			break;
		case 26:
			if(prompt26good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 1;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 1;
			}
			prompt9good = false;
			prompt10good = false;
			prompt11good = false;
			prompt12good = false;
			prompt13good = false;
			prompt14good = false;
			prompt15good = false;
			prompt16good = false;
			prompt17good = false;
			prompt18good = false;
			prompt19good = true;
			prompt20good = true;
			prompt21good = false;
			prompt22good = false;
			prompt23good = false;
			prompt24good = true;
			prompt25good = false;
			prompt27good = true;
			prompt27amazing = true;
			prompt27awful = false;
			break;
		case 27:
			if(prompt27amazing == true)
			{
				cout << "The audiecne really liked that." << endl;
				audienceMood += 5;
			}
			else if(prompt27awful == true)
			{
				cout << "The audiecne hated that. Seriously who ends a stand up routine with 'when suddenly'?!" << endl;
				audienceMood -= 100;
			}
			else if(prompt27good == true)
			{
				cout << "The audiecne liked that." << endl;
				audienceMood += 2;
			}
			else
			{
				cout << "The audience disliked that." << endl;
				audienceMood -= 2;
			}
			break;
	}
}

void reaction()
{
	cout << "Audience's reaction: ";
	if(audienceMood <= -3)
	{
		cout << "Disappointed" << endl;
		stars = 1;
	}
	else if(audienceMood > -3 and audienceMood < 2)
	{
		cout << "Unamused" << endl;
		stars = 2;
	}
	else if(audienceMood >= 2 and audienceMood < 4)
	{
		cout << "Neutral" << endl;
		stars = 3;
	}
	else if(audienceMood >= 4 and audienceMood <= 6)
	{
		cout << "Smiling" << endl;
		stars = 4;
	}
	else
	{
		cout << "Laughing" << endl;
		stars = 5;
	}
	if(roundCounter == 8 and choice != 27)
	{
		cout << "The audience feels like they've seen enough of your routine." << endl;
	}
	cout << endl;
}

int main()
{
	unsigned int newPrompts;
	string starters[8] = { "1: One time I was driving to work and", "2: I used to work as a pizza delivery guy", "3: This one happened in high school", "4: My boss was a dick", "5: So I was on my way here and", "6: I had to stop at the gas station", "7: My first date was rough", "8: So I was talking to my buddy Alex"};
	string stories[18] = { "9: A cop pulled me over", "10: He asked me 'you got any cash on you?'", "11: He didn't say much", "12: I was just minding my own business, when suddenly", "13: I ended up spilling my drink", "14: I realized I left my wallet at home", "15: I had to change my clothes", "16: He didn't like what I was wearing", "17: I just kinda stared at him", "18: He said 'you got a problem?'", "19: Talk about awkward", "20: I got yelled at for ten minutes", "21: Apparently his order got screwed up", "22: I had to go to the bathroom really bad", "23: He sat next to me and wouldn't stop coughing", "24: Guess what? I got sick!", "25: I tried to politely ask him to move", "26: I hope you all learn from my mistake"};
	int chosenPrompts[3] = {99, 100, 101};
	
	cout << endl << "Welcome to Stand Up Guy!" << endl << "Rules:" << endl << "Choose a prompt by typing the corresponding number and pressing enter." << endl << "Choosing prompts that naturally lead into eachother will generate a favorable reaction from the audience." << endl << "The audience won't like it if you end the routine too early or drag it out for too long." << endl << "----------" << endl << endl;
	cout << "Press enter to begin" << endl;
	cin.ignore();
	reaction();
	srand(time(0));
	for(int a = 0; a < 3; a++)
	{
		newPrompts = (rand() % 7);
		if(newPrompts == chosenPrompts[0] or newPrompts == chosenPrompts[1] or newPrompts == chosenPrompts[2])
		{
			a--;
		}
		else
		{
			chosenPrompts[a] = newPrompts;
		}
	}
	cout << starters[chosenPrompts[0]] << endl;
	cout << starters[chosenPrompts[1]] << endl;
	cout << starters[chosenPrompts[2]] << endl;
	cin >> choice;
	roundCounter += 1;
	firstChoice();
	cout << endl << "----------" << endl << endl;
	
	while(choice != 27 and audienceMood > -3)
	{
		if(roundCounter > 8)
		{
			audienceMood -= dragging;
			dragging += 1;
		}
		reaction();
		for(int b = 0; b < 3; b++)
		{
			newPrompts = (rand() % 17);
			if(newPrompts == chosenPrompts[0] or newPrompts == chosenPrompts[1] or newPrompts == chosenPrompts[2])
			{
				b--;
			}
			else
			{
				chosenPrompts[b] = newPrompts;
			}
		}
		cout << stories[chosenPrompts[0]] << endl;
		cout << stories[chosenPrompts[1]] << endl;
		cout << stories[chosenPrompts[2]] << endl;
		if(roundCounter > 2)
		{
			cout << "27: End the routine." << endl;
		}
		cin >> choice;
		roundCounter += 1;
		storyChoice();
	}
	
	cout << endl << "----------" << endl << endl;
	if(roundCounter == 4)
	{
		audienceMood -= 4;
	}
	else if (roundCounter == 5)
	{
		audienceMood -= 1;
	}
	reaction();
	cout << "Your stand up routine was rated " << stars << " out of 5!" << endl << "Thanks for playing Stand Up Guy!";
	
	cin.ignore();
	return 0;
}
