
let weight, height, age, gender, activityMultiplyer, rating;
let inputTypeNum = 0;
let recCals = 0;
let totalCals = 0;
let numBrInputs = 1;
let numLuInputs = 1;
let numDiInputs = 1;
let numSnInputs = 1;
let numDeInputs = 1;
let numDays = 1;
let labels = document.querySelectorAll("label");
let inputType = document.getElementById("inputChoice");
let calcButton = document.getElementById("calculate");
let addBreakfastButton = document.getElementById("addBreakfast");
let addLunchButton = document.getElementById("addLunch");
let addDinnerButton = document.getElementById("addDinner");
let addSnackButton = document.getElementById("addSnack");
let addDessertButton = document.getElementById("addDessert");
let breakfastInputArea = document.getElementById("breakfastInput");
let lunchInputArea = document.getElementById("lunchInput");
let dinnerInputArea = document.getElementById("dinnerInput");
let snacksInputArea = document.getElementById("snacksInput");
let dessertInputArea = document.getElementById("dessertInput");
let outputDiv = document.getElementById("output");
let outputArea = document.getElementById("display");
let outputArea2 = document.getElementById("display2");
let outputArea3 = document.getElementById("display3");
let saveDayButton = document.getElementById("followUpButton");
let recMessage = "";
let spanText = "";
let canSaveDay = false;
var days = [];

function Day(dayNum, calRec, calTotal, ratingType, improving) {
    this.dayNum = dayNum;
    this.calRec = calRec;
    this.calTotal = calTotal;
    this.ratingType = ratingType; // 0 = fine, 1 = eat more, 2 = eat less
    this.improving = improving; // 0 = still good, 1 = bad to good, 2 = better but not good, 3 = good to bad, 4 = bad and got worse
    this.getRating = function() {
        return this.ratingType;
    }
    this.getNetDif = function() {
        return Math.abs(this.calTotal - this.calRec);
    }
    this.makeInnerHTML = function () {
        var this_str = "<h3>Day " + this.dayNum + "</h3><p>Recommended Calories: " + this.calRec + "</p><p>Total Calories Consumed: " + this.calTotal + "</p><p>On this day, you ate ";
        switch(this.ratingType) {
            case 0:
                this_str += "a healthy amount of food.</p>";
                break;
            case 1:
                this_str += "too little food.</p>";
                break;
            case 2:
                this_str += "too much food.</p>";
                break;
            default:
                break;
        }
        if(this.dayNum != 1) {
            this_str += "<p>Since the previous day, your eating habits have ";
            switch(this.improving) {
                case 0:
                    this_str += "stayed healthy.</p>";
                    break;
                case 1:
                    this_str += "improved.</p>";
                    break;
                case 2:
                    this_str += "improved, but they still need work.</p>";
                    break;
                case 3:
                    this_str += "have gone from healthy to unhealthy.</p>";
                    break;
                case 4:
                    this_str += "worsened even further.</p>"
                    break;
                default:
                    break;
            }
        }
        return this_str;
    }
}

function updateInputType() {
    inputTypeNum = inputType.value;
    if(inputTypeNum == 1) {
        labels[2].textContent = "Enter your weight in kilograms:";
        labels[3].textContent = "Enter your height in centimeters:";
    } else if(inputTypeNum == 2) {
        labels[2].textContent = "Enter your weight in pounds:";
        labels[3].textContent = "Enter your height in inches:";
    }
}

function addFoodItem(foodTypeNum) {
    let idName = "";
    let newLabel = document.createElement("label");
    newLabel.textContent = "Name:";
    let newInput = document.createElement("input");
    newInput.setAttribute('type', 'text');
    newInput.classList.add("entry");
    let newLabel2 = document.createElement("label");
    newLabel2.textContent = "Calories:";
    let newInput2 = document.createElement("input");
    newInput2.setAttribute('type', 'number');
    newInput2.classList.add("entry");
    let newSpan = document.createElement("span");
    newSpan.classList.add("calError");
    let newBr = document.createElement("br");
    switch(foodTypeNum) {
        case 1:
            numBrInputs++;
            idName = "breakfastName" + numBrInputs;
            newLabel.setAttribute('for', idName);
            newInput.setAttribute('id', idName);
            newInput.classList.add("bN");
            idName = "breakfastCal" + numBrInputs;
            newLabel2.setAttribute('for', idName);
            newInput2.setAttribute('id', idName);
            newInput2.classList.add("bC");
            breakfastInputArea.append(newLabel, newInput, newLabel2, newInput2, newSpan, newBr);
            break;
        case 2:
            numLuInputs++;
            idName = "lunchName" + numLuInputs;
            newLabel.setAttribute('for', idName);
            newInput.setAttribute('id', idName);
            newInput.classList.add("lN");
            idName = "lunchCal" + numLuInputs;
            newLabel2.setAttribute('for', idName);
            newInput2.setAttribute('id', idName);
            newInput2.classList.add("lC");
            lunchInputArea.append(newLabel, newInput, newLabel2, newInput2, newSpan, newBr);
            break;
        case 3:
            numDiInputs++;
            idName = "dinnerName" + numDiInputs;
            newLabel.setAttribute('for', idName);
            newInput.setAttribute('id', idName);
            newInput.classList.add("diN");
            idName = "dinnerCal" + numDiInputs;
            newLabel2.setAttribute('for', idName);
            newInput2.setAttribute('id', idName);
            newInput2.classList.add("diC");
            dinnerInputArea.append(newLabel, newInput, newLabel2, newInput2, newSpan, newBr);
            break;
        case 4:
            numSnInputs++;
            idName = "snackName" + numSnInputs;
            newLabel.setAttribute('for', idName);
            newInput.setAttribute('id', idName);
            newInput.classList.add("sN");
            idName = "snackCal" + numSnInputs;
            newLabel2.setAttribute('for', idName);
            newInput2.setAttribute('id', idName);
            newInput2.classList.add("sC");
            snacksInputArea.append(newLabel, newInput, newLabel2, newInput2, newSpan, newBr);
            break;
        case 5:
            numDeInputs++;
            idName = "dessertName" + numDeInputs;
            newLabel.setAttribute('for', idName);
            newInput.setAttribute('id', idName);
            newInput.classList.add("deN");
            idName = "dessertCal" + numDeInputs;
            newLabel2.setAttribute('for', idName);
            newInput2.setAttribute('id', idName);
            newInput2.classList.add("deC");
            dessertInputArea.append(newLabel, newInput, newLabel2, newInput2, newSpan, newBr);
            break;
        default:
            break;
    }
}

function makeCalculation() {
    let canCalc = true;
    let mealTotals = [0, 0, 0, 0, 0]; // 0 = breakfast 1 = lunch 2 = dinner 3 = snack 4 = dessert
    let ateLeastDuring = 0; // 0 = breakfast 1 = lunch 2 = dinner 3 = snack 4 = dessert
    let ateMostDuring = 0; //breakfast, lunch, and dinner
    let ateMostDuringExtra = 0; //snacks and dessert
    let totalMessage = "";
    let feedback = "";
    let spans = document.querySelectorAll("span");
    var genderChoices = document.getElementsByName('gender');
    totalCals = 0;
    for(let i = 0; i < spans.length; i++) {
        spans[i].textContent = "";
    }

    if(genderChoices[0].checked) {
        gender = "male";
    } else if(genderChoices[1].checked) {
        gender = "female";
    } else {
        canCalc = false;
        spanText = "Please choose a gender!";
        spans[0].textContent = spanText;
    }

    weight = document.getElementById('weightInput').value;
    weight = parseFloat(weight);
    if(isNaN(weight) || weight <= 0) {
        canCalc = false;
        spanText = "Please input your weight!";
        spans[2].textContent = spanText;
    }

    height = document.getElementById('heightInput').value;
    height = parseFloat(height);
    if(isNaN(height) || height <= 0) {
        canCalc = false;
        spanText = "Please input your height!";
        spans[3].textContent = spanText;
    }

    inputTypeNum = parseInt(inputTypeNum);
    switch(inputTypeNum) {
        case 0:
            canCalc = false;
            spanText = "Please select the type of measurements!";
            spans[1].textContent = spanText;
            break;
        case 1:
            break;
        case 2:
            weight = weight / 2.205;
            height = height * 2.54;
            break;
        default:
            break;
    }

    age = document.getElementById('ageInput').value;
    age = parseFloat(age);
    if(isNaN(age) || age <= 0) {
        canCalc = false;
        spanText = "Please input your age!";
        spans[4].textContent = spanText;
    }

    let activeFound = false;
    let activeChoices = document.getElementsByName('activity');
    for(let i = 0; i < activeChoices.length; i++) {
        if(activeChoices[i].checked) {
            activeFound = true;
            switch(i) {
                case 0:
                    activityMultiplyer = 1.2;
                    break;
                case 1:
                    activityMultiplyer = 1.375;
                    break;
                case 2:
                    activityMultiplyer = 1.55;
                    break;
                case 3:
                    activityMultiplyer = 1.725;
                    break;
                case 4:
                    activityMultiplyer = 1.9;
                    break;
                default:
                    break;
            }
            break;
        }
    }
    if(activeFound == false) {
        canCalc = false;
        spanText = "Please choose an activity level!";
        spans[5].textContent = spanText;
    }

    let foodInputs = document.querySelectorAll("input.entry");
    let foodNames = [];
    let foodCals = [];
    let j = 0;
    for(let i = 0; i < foodInputs.length; i+=2) {
        foodNames[j] = foodInputs[i];
        foodCals[j] = foodInputs[i + 1];
        j++;
    }

    let calErrorSpans = document.querySelectorAll('span.calError');

    for(let i = 0; i < foodNames.length; i++) {
        let foodCalsNum = parseInt(foodCals[i].value);
        if(foodCalsNum < 0) {
            calErrorSpans[i].textContent = "Please enter a positive number.";
            canCalc = false;
        } else if(foodNames[i].value != "" && isNaN(foodCalsNum)) {
            calErrorSpans[i].textContent = "Please enter the number of calories of this item.";  
            canCalc = false;
        } else if(foodNames[i].value == "" && !isNaN(foodCalsNum)) {
            calErrorSpans[i].textContent = "Please enter the name of this item.";  
            canCalc = false;
        } else if(foodNames[i].value != "" && !isNaN(foodCalsNum)) {
            totalCals += foodCalsNum;
            if(foodCals[i].classList.contains('bC')) {
                mealTotals[0] += foodCalsNum;
            } else if(foodCals[i].classList.contains('lC')) {
                mealTotals[1] += foodCalsNum;
            } else if(foodCals[i].classList.contains('diC')) {
                mealTotals[2] += foodCalsNum;
            } else if(foodCals[i].classList.contains('sC')) {
                mealTotals[3] += foodCalsNum;
            } else if(foodCals[i].classList.contains('deC')) {
                mealTotals[4] += foodCalsNum;
            }
        }
    }

    let currentLeast = 99999;
    let currentMost = 0;
    let currentMostExtra = 0;
    for(let i = 0; i < mealTotals.length; i++) {
        if(i < 3) {
            if(mealTotals[i] < currentLeast) {
                currentLeast = mealTotals[i];
                ateLeastDuring = i;
            }
            if(mealTotals[i] > currentMost) {
                currentMost = mealTotals[i];
                ateMostDuring = i;
            }
        } else {
            if(mealTotals[i] > currentMostExtra) {
                currentMostExtra = mealTotals[i];
                ateMostDuringExtra = i;
            }
        }
    }

    if(canCalc == false) {
        recMessage = "Could not calculate. Try again.";
        hideButton();
    } else {
        showButton();
        if(gender == "male") {
            recCals = ((10 * weight) + (6.25 * height) - (5 * age) + 5) * activityMultiplyer;
        } else if(gender == "female") {
            recCals = ((10 * weight) + (6.25 * height) - (5 * age) - 161) * activityMultiplyer;
        }
        recCals = recCals.toFixed(0);
        recCals = parseInt(recCals);
        recMessage = "Your recommeded caloric intake: " + recCals + " calories.";
        totalMessage = "Your total caloric intake: " + totalCals + " calories.";
        if(totalCals < (recCals - 300)) {
            feedback = "You should eat more during ";
            switch(ateLeastDuring) {
                case 0:
                    feedback += "breakfast.";
                    break;
                case 1:
                    feedback += "lunch.";
                    break;
                case 2:
                    feedback += "dinner.";
                    break;
            }
            rating = 1;
        } else if(totalCals > (recCals + 300)) {
            feedback = "You should eat less during ";
            if(ateMostDuringExtra != 0 && ((totalCals - mealTotals[ateMostDuringExtra]) < (recCals + 300))) {
                switch(ateMostDuringExtra) {
                    case 3:
                        feedback += "snacks.";
                        break;
                    case 4:
                        feedback += "dessert.";
                        break;
                }
            } else {
                switch(ateMostDuring) {
                    case 0:
                        feedback += "breakfast.";
                        break;
                    case 1:
                        feedback += "lunch.";
                        break;
                    case 2:
                        feedback += "dinner.";
                        break;
                }
            }
            rating = 2;
        } else {
            feedback = "Your eating habits are fine.";
            rating = 0;
        }
    }
    outputArea.textContent = recMessage;
    outputArea2.textContent = totalMessage;
    outputArea3.textContent = feedback;
}

function showButton() {
    if (saveDayButton.classList.contains("hidden") == true) {
        saveDayButton.classList.remove("hidden");
    }
    canSaveDay = true;
}

function hideButton() {
    if (saveDayButton.classList.contains("hidden") == false) {
        saveDayButton.classList.add("hidden");
    }
    canSaveDay = false;
}

function addDay() {
    if(canSaveDay == true) {
        let foodInputs = document.querySelectorAll("input.entry");
        for(let i = 0; i < foodInputs.length; i++) {
            foodInputs[i].value = "";
        }
        if(numDays == 1) {
            let newDay = new Day(numDays, recCals, totalCals, rating, 0);
            days[numDays - 1] = newDay;
        } else {
            let improvement;
            let pastRating = days[numDays - 2].getRating();
            pastRating = parseInt(pastRating);
            console.log("Past:  " + pastRating);
            if (rating == 0 && pastRating == 0) {
                improvement = 0;
            } else if (rating == 0 && pastRating > 0) {
                improvement = 1;
            } else if (rating > 0 && pastRating == 0) {
                improvement = 3;
            } else {
                let netCals1 = Math.abs(totalCals - recCals);
                let netCals2 = days[numDays - 2].getNetDif();
                if (netCals1 < netCals2) {
                    improvement = 2;
                } else {
                    improvement = 4;
                }
            }
            let newDay = new Day(numDays, recCals, totalCals, rating, improvement);
            days[numDays - 1] = newDay;
        }
        console.log("Current:  " + rating);
        let newDiv = document.createElement("div");
        newDiv.classList.add("day");
        newDiv.innerHTML = days[numDays - 1].makeInnerHTML();
        outputDiv.append(newDiv);
        numDays++;
        hideButton();
    }
}

inputType.addEventListener('change', updateInputType, false);
addBreakfastButton.addEventListener('click', function(){addFoodItem(1)}, false);
addLunchButton.addEventListener('click', function(){addFoodItem(2)}, false);
addDinnerButton.addEventListener('click', function(){addFoodItem(3)}, false);
addSnackButton.addEventListener('click', function(){addFoodItem(4)}, false);
addDessertButton.addEventListener('click', function(){addFoodItem(5)}, false);
calcButton.addEventListener('click', makeCalculation, false);
saveDayButton.addEventListener('click', addDay, false);